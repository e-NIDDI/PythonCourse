file_path = "example.txt"
file = open(file_path,"r")

content = file.read()
print(content)

file.close


file_path = "example.txt"
with open(file_path,"r") as file:
       content = file.read()
       print(content)

with open("example.txt","r") as file:
       linel = file.readline()
       print(linel)


with open("example.txt","w") as file:
       file.write("Hello World")

   
lines =['Hello,World?\n','Welcome to python?\n']
with open("example.txt","w") as file:
       file.writelines(lines)

with open("example.txt","r") as file:
       file.seek(0)
       data = file.read()
       print(data)

import os
if os.path.exists("example.txt"):
       print("File exists!")

with open("example.txt", "a") as file:
       file.write("New data appended.")

data = b'This is some binary data'
with open('example.bin', 'wb') as file:
    file.write(data)

with open("binary_file.bin", "rb") as binary_file:
       data = binary_file.read()