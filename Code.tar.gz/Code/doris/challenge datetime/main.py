import datetime

now = datetime.datetime.now()

print(f"Year: {now.year}")
print(f"Month: {now.month}")
print(f"Day: {now.day}")
print(f"Hour: {now.hour}")
print(f"Minute: {now.minute}")
print(f"Second: {now.second}")
print(f"Microsecond: {now.microsecond}")


from datetime import datetime, timedelta

now = datetime.now()

years_in_days = 100 * 365.25

date_100_years_ago = now - timedelta(days=years_in_days)
date_100_years_from_now = now + timedelta(days=years_in_days)

print(f"Current date: {now}")
print(f"100 years ago: {date_100_years_ago}")
print(f"100 years from now: {date_100_years_from_now}")
