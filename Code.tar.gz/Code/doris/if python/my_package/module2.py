def greet():
    print("Greetings from module2")