def hello():
    print("Hello from module")
    