def welcome():
    print("Welcome from module")