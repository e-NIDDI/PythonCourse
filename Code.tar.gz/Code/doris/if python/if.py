#if condition:

#elif another_condition:

##else:

age = 18

if age >= 18:
	print ("You can vote.")
else:
	print("You cannot vote yet.")

#if condition1:
	#if condition2:

	#else:


#else:


temperature = 28

if temperature > 30:
	print("It's a hot day, stay hydrated.")
elif 20 <= temperature <= 30:
	print("The weather is pleasant.")
else:
	print("It's a cold day, bundle up.")

student_gpa = 4.5
student_score = 75


if student_gpa >= 3.5:
	if 50 <= student_score <= 65:
		print(f"student with GPA {student_gpa} and test score of {student_score} may be eligible for partial "f"scolarship.")
	elif student_score > 65:
		print(f"student with GPA {student_gpa} and test score of {student_score} is eligible for a full scolarship.")
	else:
		print(f"student with GPA {student_gpa} and test score of {student_score} is not eligible for a scolarship.")
else:
	print(f"student with GPA {student_gpa} and test score of {student_score} is not eligible for a scolarship.")
	
names = ["Alice", "Bob", "Charlie", "David"]


for name in names:
	print(name)
	
    
sentence = "Hello, World"

for character in sentence:
	if character.isalpha():
		print(character)
		

for number in range(1, 6):
	print(number)
	

numbers = [12, 45, 6, 72, 21, 8, 94, 57]

#initialize a variable "maximum" with the firs value from the list "numbers".
maximum = numbers[0]

#for num in numbers: #Begin a loop iterating through each element in the list "numbers".
    #if num > maximum: #Check if the current element "num" is greater than current maximum value.
		#maximum = num #If so, update the maximum value to be the current element "num"
#print("The maximum value in the list is:", maximum)

count = 1

while count <= 5:
	print("Iteration", count)
	count += 1


numbers = [1, 2, 3, 4, 5, 6]
target = 4

for number in numbers:
	print(number)
	if number == target:

		print("Target found!")
		break


scores = [68, 42, 57, 78, 35, 62, 50, 92]
total = 0
count = 0

for score in scores:
	if score < 50:
		continue

	total += score
	count += 1

average = total / count if count > 0 else 0

print("Average score for scores above 50:", average)


while True:
	user_input = input("Enter a pozitive number: ")

	if user_input.isnumeric():
		number = int(user_input)
		if number > 0:
			break

print("Invalid input. Please try again.")

print("You entered a valid pozitive number:", number)



total = 0

for number in range(1, 11):
	if number % 2 == 0:
		total += number

print("The sum of even numbers from 1 to 10 is:", total)


def greet():
	print("Hello World!")

greet()

def greet_person(name):
	print("Hello,", name)

greet_person("Alice	")


#result = add(3, 7)
#print("3 + 7 =", result)



def greet(name):
	message = f"Hello, {name}!"

	print(message)

greet("Alice")

#print(message)


greeting = "Hello"

def greet(name):

	message = f"{greeting}, {name}!"
	print(message)

greet("Bob")

print(greeting)



greeting = "Hello"


def greet(name):
	global message

	message = f"{greeting}, {name}!"

	print(message)

greet("Bob")

print(message)

message = f"{greeting}, student!"

print(message)


greeting = "Hello"
name = "Bob"


def greet():
	global greeting
	greeting = "Goodbye"

	name = "Alice"

	message = f"{greeting}, {name}!"
	print(message)

	
greet()

print(greeting)

print(name)


def greet_person(name, greeting="Hello"):
	message = f"{greeting}, {name}!"
	return message

default_greeting = greet_person("Alice")

custom_greeting = greet_person("Bob", "Hi")

print(default_greeting)
print(custom_greeting)