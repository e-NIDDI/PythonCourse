def calculate(number1, number2, operator):
    """Performs the given arthmetic operation on two numbers."""
    if operator == '+':
        return number1 + number2
    elif operator == '-':
        return number1 - number2
    elif operator == '*':
        return number1 * number2
    elif operator == '/':
        return number1 / number2
    else:
        raise ValueError("Invalid operation")
    


try:
    num1 = float(input("Enter the first number: "))
    num2 = float(input("Enter the second number: "))
    operation = input("Enter an operation (+, -, *, /): ")
    result = calculate(num1, num2, operation)
    print(f"The result of {num1} {operation} {num2} is: {result}")

except ValueError as e:
    print(f"Invalid input: {e}")
except ZeroDivisionError:
    print("cannot divide by zero.")
except Exception as e:
    print(f"An unexpected error occurred: {e}")
finally:
    print("End of program")


def calculate_area(length, width):
    return length + width

def calculate_perimeter(length, width):
    return 2 * (length + width)

length = 5
width = 3

area = calculate_area(length, width)
perimeter = calculate_perimeter(length, width)

print(f"Area: {area}")
print(f"Perimeter: {perimeter}")


class Student:
    def __init__(self, name, percentage):

        self.name = name
        self.percentage = percentage

    def show(self):
        print("Name is", {self.name}, "and percentage is", {self.percentage})

                                                                                                                                                                                                                                                                                                                                                                                                                                                        
stud = Student("Doris",80)

stud.show()




class Person:
    def __init__(self, name, age):
        self.name = name
        self.age = age

    def greet(self):
        print(f"Hello, I am {self.name}, and I am {self.age} years old.")

    
person1 = Person("Alice", 15)
person2 = Person("Bob", 17)

person1.greet()
person2.greet()


class Student:
    school_name = "Digital School"

student_1 = Student()

print(student_1.school_name)


class Student:
    school_name = "Digital School"

    def __init__(self, name, age, course):
        self.name = name
        self.age = age
        self.course = course


student_1 = Student("Alice", 15, "Python")
student_2 = Student("Bob", 16, "Javascript")

print(student_1.course)
print(student_2.course)


class MyClass:

    def __init__(self):
        self.public_variable = "This is a public variable"


my_class = MyClass()

print(my_class.public_variable)



class MyClass:
    def __init__(self):
        self.__private_variable = "This is a private variable"

    def __private_method(self):
        print("This is a private method")


my_class = MyClass()

print(my_class.__private_variable)  


class MyClass:
    def __init__(self):
        self._protected_variable = "This is a protected variable"

    
    def _protected_method(self):
        print("This is a protected method")

my_class = MyClass()

print(my_class._protected_variable)

my_class._protected_method()

