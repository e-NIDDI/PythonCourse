age = 25

age_as_str = str(age)

print(age_as_str, "of type", type(age_as_str))


print(bool(0))
print(bool(42))

print(bool(""))
print(bool("Hello"))

print(bool([]))

print(bool(None))


x = 32
y = 5.3

result = x + y
print(result, "of type", type(result))

age = 25
message = "I am" + str(age) + " years old"
print(message)


a = 5
b = "3"
result1 = a * int(b)
print(result1, "of type", type(result1))

#z = int("abc")



name = input("Enter your name: ")
print(f"Hello, {name}")

age = input("Enter your age: ")

print(type(age))



number1 = input("Enter the first number: ")

number2 = input("Enter thge second number: ")

result = int(number1) + int(number2)

print(f"The sum of {number1} and {number2} is {result}")


#number1 = int(input("Enter the first number: "))

#number2 = int(input("Enter thge second number: "))

#result = number1 + number2

#print(f"The sum of {number1} and {number2} is {result}")


#number1 = input("Enter the first number: ")

#number2 = input("Enter thge second number: ")

#result = number1 + number2

#print(f"The sum of {number1} and {number2} is {result}")

try:
    result = 10/0
except ZeroDivisionError:
    print("Oops! Tried to divide to zero.")


fruits = {"apple": 5,
          "banana": 7,
          "orange": 3}

try:
    print(fruits["cherry"])

except KeyError:
    print("The key does not exist in the dictionary")


text = "This is not a number"

try:
    text_init_int = init(text)

except Exception as e:

    print("An error occurred while parsing the data: ", e)


try:
    result = 10 / 2
except ZeroDivisionError:
    print("Division by zero error occurred")
else:
    print("Division successful. Result:", result)


try:
    result = 10 / 2
except ZeroDivisionError:
    print("Cannot divide by zero")
finally:
    print("Finally block executed")


def divide_numbers(a, b):
    try:
        result = a / b
        print("Result of division:", result)
    except ZeroDivisionError:
        print("Invalid division by zero.")
    except TypeError:
        print("Invalid type of division.")
    except Exception as e:
        print(f"Unexpected error: {e}") 



