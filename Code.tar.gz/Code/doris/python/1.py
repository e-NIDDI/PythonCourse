print("Hello World")


temperature = 80.6

print(type(temperature))


first_name = "John"
last_name = "Doe"
full_name = first_name + " " +last_name
print(full_name)


shopping_list = ["apples","banana",3,4,5]
print(shopping_list[0])

shopping_list.append("orange")
print(shopping_list)

shopping_list.insert(2,"lemons")
print(shopping_list)

shopping_list.remove("apples")
print(shopping_list)

del shopping_list[2]
print(shopping_list)

shopping_list[0] = "watermelon"
print(shopping_list)



words = ("eggs","spam","sausages")
print(words[0])

empty_typle = ()


person = ("Alice",30,"Engineer")

name,age,proffesion = person
print(name, "'s"," proffeson is" , proffesion," and she is",age,"years old")

my_dictinary = {
"key1" : "value1",
"key2" : "value2",
"key3" : "value3"

}

contact_info = {
"Alice" : "555-1234",
"Bob" : "555-5678"
}
print(contact_info)

alice_phone = contact_info["Alice"]
print(alice_phone)

contact_info["Alice"] = "555-4321"
print(contact_info)

contact_info["Eve"] = "555-9999"
print(contact_info)

del contact_info["Bob"]
print(contact_info)

keys = contact_info.keys()
print(keys)

values = contact_info.values()
print(values)

items = contact_info.items()
print(items)



contact_information = {
"Alice": {
"phone_number": "555-1234",
"email": "alice@gmail.com",
"home_address": "123 Main St, Cityville",
"birthday": "20/11/2000"

},
"Bob": {
"phone_number": "555-1234",
"email": "bob@gmail.com",
"home_address": "456 Main St, Cityville",
"birthday": "15/09.1997"
},
"Eve": {
"phone_number": "555-9999",
"email": "eve@gmail.com",
"home_address": "789 Main St, Cityville",
"birthday": "05/03/2001"
}
}

print(contact_information)

bob_information = contact_information["Bob"]
print(bob_information)


jane_contact = {
	'name': 'Jane',
	'phone': '123-456-7890',
	'email': 'jane@example.com'
}

john_contact = {
	'name': 'John',
	'phone': '987-654-3210',
	'email': 'john@example.com'
}

contacts = {
	'Jane': jane_contact,
	'John': john_contact
}

print("Jane`s contact information:")
print(contacts['Jane'])

contacts['Jane']['phone'] = '111-222-333'

print("\nJane`s updated contact information:")
print(contacts['Jane'])

grades = {
	("John", "Math"): 5,
	("Alice", "Biology"): 4,
	("Bob", "Physics"): 3.5,
	("Eve", "Music"): 5,
	("John", "English"): 4
}

john_math = grades[("John", "Math")]
print("John`s grade in math is", john_math)

grades[("Bob", "Math")] = 3
print(grades)

keys = list(grades.keys())

student, subject = keys[0]
print(student, "`s grade in", subject, " is ", john_math)

books = {
	("1984", "George Orwell"): "Dystopian",
	("To Kill a Mockingbird", "Harper Lee"): "Classic",
	("The great Gatsby", "F. Scott Fitzgerald"): "Classic"
}

books[("Brave New World", "Aldous Hucley")] = "Dystopian"

book_info = books[("1984", "George Orwell")]
print("1984`s genre:", book_info)

book_info = books[("Brave New World", "Aldous Huxley")]
print("Brave New World`s genre:", book_info)