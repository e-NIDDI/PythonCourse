with open('example.txt', 'r') as file:
    for line in file:
        cleaned_line = line.strip()  # Remove leading/trailing whitespace
        print(cleaned_line)

with open('example.txt', 'r') as file:
    for line in file:
        words = line.strip().split()  # Split line into words
        print(words)

# Writing to a file
name = "Alice"
age = 30

with open('output.txt', 'w') as file:
    file.write(f"Name: {name}\n")
    file.write(f"Age: {age}\n")

# Reading from one file and writing to another
with open('example.txt', 'r') as infile, open('output.txt', 'w') as outfile:
    for line in infile:
        cleaned_line = line.strip()  # Remove leading/trailing whitespace
        modified_line = cleaned_line.replace("line 1", "Line X")  # Replace text
        outfile.write(modified_line + "\n")  # Write modified line to output file

# Working with datetime
import datetime

current_datetime = datetime.datetime.now()

print("Year:", current_datetime.year)
print("Month:", current_datetime.month)
print("Day:", current_datetime.day)
print("Hour:", current_datetime.hour)
print("Minute:", current_datetime.minute)
print("Second:", current_datetime.second)
print("Microsecond:", current_datetime.microsecond)

current_date = datetime.datetime.now().date()

print("Year:", current_date.year)
print("Month:", current_date.month)
print("Day:", current_date.day)

current_time = datetime.datetime.now().time()

# Creating a time object
from datetime import time

time_object = time(12, 30, 45, 123456)

print("Hour:", time_object.hour)
print("Minute:", time_object.minute)
print("Second:", time_object.second)
print("Microsecond:", time_object.microsecond)

# Creating a specific date and time
specific_date = datetime.date(2024, 4, 5)
specific_time = datetime.time(12, 30, 0)

# Formatting a datetime object
from datetime import datetime

specific_datetime = datetime(2024, 1, 1, 14, 30, 0)
formatted_date = specific_datetime.strftime('%Y-%m-%d %H:%M:%S')
print(formatted_date)  # Output: 2024-01-01 14:30:00

# Working with timedelta
from datetime import timedelta

duration = timedelta(days=5, hours=3)
current_date = datetime.now()

new_date = current_date + duration
print("New Date:", new_date)

previous_date = current_date - duration
print("Previous Date:", previous_date)

# Working with time zones
import datetime

utc_time = datetime.datetime.now(datetime.timezone.utc)
print("Current UTC time:", utc_time)

custom_offset = datetime.timedelta(hours=3)
custom_time = utc_time.replace(tzinfo=datetime.timezone(custom_offset))
print("Current time in custom time zone (UTC+3):", custom_time)