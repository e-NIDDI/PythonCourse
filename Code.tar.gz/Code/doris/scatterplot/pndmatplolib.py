import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv('avgIQpercountry.csv')

plt.figure(figsize=(10, 6))

plt.scatter(df['Mean years of schooling - 20211'], df['Average IQ'],
            color='purple', alpha=0.7)

plt.title('Scatter Plot of Mean Years of Schooling vs. Average IQ')

plt.xlabel('Mean years of schooling - 2021')

plt.ylabel('Average IQ')

plt.grid(True, linestyle='--', alpha=0.7)



import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv('avgIQpercountry.csv')

nobel_prizes_by_continent = df.groupby('Continent')['Nobel Prices'].sum()
 
no_of_continents = nobel_prices_by_continent.count()

print(no_of_continents)

colors = ['gold', 'lightcoral', 'yellow', 'thistle', 'orange', 'lightskyblue', 'aquamarine', 
          'burlywood']

plt.figure(figsize=(10,10))

nobel_prizes_by_continent.plot(kind='pie', colors=colors, autopct='%1.1f%%')

plt.title('Distribution of Nobel Prizes by cotinent')

plt.axis('equal')

plt.ylabel('')

plt.tight_layout()

plt.show()