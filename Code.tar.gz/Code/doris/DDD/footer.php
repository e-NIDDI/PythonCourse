<footer>
    <p>&copy; 2025 RXR Computers. All rights reserved.</p>
</footer>

<script>
    document.addEventListener("DOMContentLoaded", function () {
    const slides = document.querySelectorAll('.my-slider .slide'); // All the slides
    let currentSlide = 0;


    function showSlide(index) {
        slides.forEach(slide => slide.classList.remove('active')); // Remove active class
        slides[index].classList.add('active'); // Add active class to the current slide
    }

    function nextSlide() {
        currentSlide = (currentSlide + 1) % slides.length; // Loop back to the first slide after the last
        showSlide(currentSlide);
    }

    function prevSlide() {
        currentSlide = (currentSlide - 1 + slides.length) % slides.length; // Loop back to the last slide before the first
        showSlide(currentSlide);
    }


    setInterval(nextSlide, 3000);


    showSlide(currentSlide);


    window.nextSlide = nextSlide;
    window.prevSlide = prevSlide;
});


    document.addEventListener("DOMContentLoaded", function () {
    const tabButtons = document.querySelectorAll(".tab-btn");
    const tabContents = document.querySelectorAll(".tab-content");

    tabButtons.forEach(button => {
        button.addEventListener("click", function () {
            const targetTab = this.getAttribute("data-tab");

            // Remove active class from all buttons
            tabButtons.forEach(btn => btn.classList.remove("active"));
            this.classList.add("active");

            // Hide all tab contents
            tabContents.forEach(content => content.classList.remove("active"));
            document.getElementById(targetTab).classList.add("active");
        });
    });
});

</script>