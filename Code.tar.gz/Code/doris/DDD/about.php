    <?php  include 'about-header.php'; ?>
    <header class="nav">
        <ul>
            <li><a href="/home/">Home</a></li>
            <li><a href="/store/">Store</a></li>
            <li><a href="/about/">About Us</a></li>
            <li><a href="/contact/">Contact Us</a></li>
        </ul>
    </header>

    <div class="header">
        <h1>About Us</h1>
    </div>
    <main>
        <section class="welcome">
            <h2>Welcome to Kosovo Cars</h2>
            <p>
                At Kosovo Cars, we are dedicated to providing the latest models and best-in-class vehicles 
                to meet your personal and professional transportation needs. Our mission is to make high-quality cars accessible 
                to everyone in Kosovo.
            </p>
        </section>
        <section class="we">
            <h2>Who We Are</h2>
            <p>
                Established in 2025, we are a passionate team of automotive enthusiasts who understand the importance of 
                reliable and efficient vehicles. We offer a carefully curated selection of sedans, SUVs, sports cars, and 
                accessories from top brands at competitive prices.
            </p>
        </section>
        <section class="why-us">
            <h2>Why Choose Us?</h2>
            <ul>
                <li>Wide range of vehicles for every need and budget</li>
                <li>Trusted by thousands of customers across Kosovo</li>
                <li>Expert support to help you choose the right car</li>
                <li>Fast and reliable delivery to your doorstep</li>
            </ul>
        </section>
        <section class="vis">
            <h2>Our Vision</h2>
            <p>
                To become the go-to destination for car sales and services in Kosovo by consistently exceeding 
                customer expectations and staying ahead in the automotive industry.
            </p>
        </section>
    </main>
    <footer>
        <p>&copy; 2025 RXR Cars. All rights reserved.</p>
    </footer>
</body>
</html>
