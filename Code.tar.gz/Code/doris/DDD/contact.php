<?php /* Template Name: contact */ ?>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $fromEmail = filter_var($_POST["from_email"], FILTER_SANITIZE_EMAIL);
    $toEmail = filter_var($_POST["to_email"], FILTER_SANITIZE_EMAIL);
    $subject = htmlspecialchars($_POST["subject"]);
    $message = nl2br(htmlspecialchars($_POST["message"]));
    
    // Validate inputs
    if (!filter_var($fromEmail, FILTER_VALIDATE_EMAIL)) {
        $error = "Invalid sender email!";
    } elseif (!filter_var($toEmail, FILTER_VALIDATE_EMAIL)) {
        $error = "Invalid recipient email!";
    } elseif (empty($subject) || empty($message)) {
        $error = "Subject and message cannot be empty!";
    } else {
        // Email headers
        $headers = "From: " . $fromEmail . "\r\n";
        $headers .= "Reply-To: " . $fromEmail . "\r\n";
        $headers .= "Content-Type: text/html; charset=UTF-8\r\n";

        // Send the email
        if (mail($toEmail, $subject, $message, $headers)) {
            $success = "Message sent successfully!";
        } else {
            $error = "Failed to send the email!";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Form</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 500px;
            margin: 20px auto;
            padding: 20px;
            border: 1px solid #ddd;
            border-radius: 8px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }
        input, textarea {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        button {
            background: #28a745;
            color: white;
            padding: 10px;
            border: none;
            cursor: pointer;
            width: 100%;
            border-radius: 5px;
        }
        .message {
            padding: 10px;
            text-align: center;
            border-radius: 5px;
        }
        .success { background: #d4edda; color: #155724; }
        .error { background: #f8d7da; color: #721c24; }
    </style>
</head>
<body>

<h2>Contact Form</h2>

<?php if (!empty($success)) echo "<div class='message success'>$success</div>"; ?>
<?php if (!empty($error)) echo "<div class='message error'>$error</div>"; ?>

<form action="" method="POST">
    <label>Your Email:</label>
    <input type="email" name="from_email" required>

    <label>Recipient's Email:</label>
    <input type="email" name="to_email" required>

    <label>Subject:</label>
    <input type="text" name="subject" required>

    <label>Message:</label>
    <textarea name="message" rows="5" required></textarea>

    <button type="submit">Send Message</button>
</form>

</body>
</html>
