<?php

add_theme_support('page-templates');


// Enqueue Scripts and Styles
function add_theme_scripts() {
    wp_enqueue_style('style', get_stylesheet_uri());
    wp_enqueue_style('custom-style', get_template_directory_uri() . '/assets/css/index.css');
    wp_enqueue_style('slider', get_template_directory_uri() . '/css/slider.css', array(), '1.1', 'all');
    wp_enqueue_script('script', get_template_directory_uri() . '/js/script.js', array('jquery'), 1.1, true);

    if (is_singular() && comments_open() && get_option('thread_comments')) {
        wp_enqueue_script('comment-reply');
    }
}
add_action('wp_enqueue_scripts', 'add_theme_scripts');

// Register Navigation Menus
function ds_setup() {
    register_nav_menu('primary', __('Primary Menu', 'theme_name'));
    add_theme_support('menus');
}
add_action('init', 'ds_setup');

// Add Theme Supports
add_theme_support('post-thumbnails');
add_theme_support('post-formats', array('aside', 'image', 'video'));

// Register Sidebars
function themename_widgets_init() {
    // Primary Sidebar
    register_sidebar(array(
        'name'          => __('Primary Sidebar', 'theme_name'),
        'id'            => 'sidebar-1',
        'before_widget' => '<aside id="%1$s" class="widget %2$s">',
        'after_widget'  => '</aside>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ));

    // Secondary Sidebar
    register_sidebar(array(
        'name'          => __('Secondary Sidebar', 'theme_name'),
        'id'            => 'sidebar-2',
        'before_widget' => '<aside id="%1$s" class="widget %2$s">',
        'after_widget'  => '</aside>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ));
}
add_action('widgets_init', 'themename_widgets_init');

// Register Deals Custom Post Type
function deals_init() {
    $labels = array(
        'name'               => _x('Deals', 'post type general name'),
        'singular_name'      => _x('Deal', 'post type singular name'),
        'add_new'            => _x('Add New', 'deal'),
        'add_new_item'       => __('Add New Deal'),
        'edit_item'          => __('Edit Deal'),
        'new_item'           => __('New Deal'),
        'all_items'          => __('All Deals'),
        'view_item'          => __('View Deal'),
        'search_items'       => __('Search Deals'),
        'not_found'          => __('No deals found'),
        'not_found_in_trash' => __('No deals found in the Trash'),
        'menu_name'          => __('Deals'),
    );

    $args = array(
        'labels'        => $labels,
        'description'   => 'Deals and single deal details',
        'public'        => true,
        'menu_position' => 5,
        'supports'      => array('title', 'editor', 'thumbnail', 'excerpt', 'comments'),
        'has_archive'   => true,
        'rewrite'       => array('slug' => 'deals'),
    );

    register_post_type('deals', $args);
}
add_action('init', 'deals_init');

// Register Products Custom Post Type
function products_init() {
    $labels = array(
        'name'               => _x('Products', 'post type general name'),
        'singular_name'      => _x('Product', 'post type singular name'),
        'add_new'            => _x('Add New', 'product'),
        'add_new_item'       => __('Add New Product'),
        'edit_item'          => __('Edit Product'),
        'new_item'           => __('New Product'),
        'all_items'          => __('All Products'),
        'view_item'          => __('View Product'),
        'search_items'       => __('Search Products'),
        'not_found'          => __('No products found'),
        'not_found_in_trash' => __('No products found in the Trash'),
        'menu_name'          => __('Products'),
    );

    $args = array(
        'labels'        => $labels,
        'description'   => 'A custom post type for managing products and product details',
        'public'        => true,
        'menu_position' => 5,
        'menu_icon'     => 'dashicons-cart',
        'supports'      => array('title', 'editor', 'thumbnail', 'excerpt', 'comments'),
        'has_archive'   => true,
        'rewrite'       => array('slug' => 'products'),
    );

    register_post_type('products', $args);
}
add_action('init', 'products_init');

function enable_custom_fields() {
    add_post_type_support('post', 'custom-fields');
}
add_action('init', 'enable_custom_fields');


?>
