<?php 
    /* Template Name: Store */
    include 'store-header.php';
?>

<header class="nav">
        <ul>
            <li><a href="/home/">Home</a></li>
            <li><a href="/store/">Store</a></li>
            <li><a href="/about/">About Us</a></li>
            <li><a href="/contact/">Contact Us</a></li>
        </ul>
    </header>

<div class="container">
    <h1>Our Deals & Products</h1>

    <!-- Tab Navigation -->
    <div class="tabs">
        <button class="tab-btn active" data-tab="deals">Deals</button>
        <button class="tab-btn" data-tab="products">Products</button>
    </div>

    <!-- Deals Section -->
    <div class="tab-content active" id="deals">
        <?php
        $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;

        $deals_args = array(
            'post_type'      => 'deals',
            'posts_per_page' => 30,
            'paged'          => $paged,
        );

        $deals_query = new WP_Query($deals_args);

        if ($deals_query->have_posts()) :
            echo '<div class="posts-grid">';
            while ($deals_query->have_posts()) : $deals_query->the_post();
        ?>
                <div class="post-item">
                    <?php if (has_post_thumbnail()) : ?>
                        <div class="post-image">
                            <?php the_post_thumbnail(); ?>
                        </div>
                    <?php endif; ?>
                    <h2 class="post-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                    <div class="post-content">
                        <?php the_excerpt(); ?>
                    </div>
                </div>
        <?php 
            endwhile;
            echo '</div>';

            // Pagination
            echo '<div class="pagination">';
            echo paginate_links(array(
                'total'   => $deals_query->max_num_pages,
                'current' => $paged,
                'prev_text' => '&laquo; Previous',
                'next_text' => 'Next &raquo;',
            ));
            echo '</div>';

            wp_reset_postdata();
        else :
            echo '<p>No deals found.</p>';
        endif;
        ?>
    </div>

    <!-- Products Section -->
    <div class="tab-content" id="products">
        <?php
        $products_args = array(
            'post_type'      => 'products',
            'posts_per_page' => 30,
            'paged'          => $paged,
        );

        $products_query = new WP_Query($products_args);

        if ($products_query->have_posts()) :
            echo '<div class="posts-grid">';
            while ($products_query->have_posts()) : $products_query->the_post();
        ?>
                <div class="post-item">
                    <?php if (has_post_thumbnail()) : ?>
                        <div class="post-image">
                            <?php the_post_thumbnail(); ?>
                        </div>
                    <?php endif; ?>
                    <h2 class="post-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                    <div class="post-content">
                        <?php the_excerpt(); ?>
                    </div>
                </div>
        <?php 
            endwhile;
            
            // Pagination
            echo '<div class="pagination">';
            echo paginate_links(array(
                'total'   => $products_query->max_num_pages,
                'current' => $paged,
                'prev_text' => '&laquo; Previous',
                'next_text' => 'Next &raquo;',
            ));
            echo '</div>';

            wp_reset_postdata();
        else :
            echo '<p>No products found.</p>';
        endif;
        ?>
    </div>
</div>

<?php get_footer(); ?>