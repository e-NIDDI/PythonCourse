<!DOCTYPE html>
<html lang="en">
<?php get_header(); ?>


    <header class="nav">
        <ul>
            <li><a href="/ /">Home</a></li>
            <li><a href="/store/">Store</a></li>
            <li><a href="/about/">About Us</a></li>
            <li><a href="/contact/">Contact Us</a></li>
        </ul>
    </header>




<div class="my-slider">
    <button class="prev" onclick="prevSlide()">Previous</button>

    <?php 
    $query = new WP_Query(array(
        'post_type' => 'post',
        'posts_per_page' => -1
    ));
    if ($query->have_posts()) :
        $index = 0; // To track the slide index
        while ($query->have_posts()) : $query->the_post();
            if (has_post_thumbnail()) :
    ?>
    <div class="slide <?php echo ($index == 0) ? 'active' : ''; ?>">
        <?php the_post_thumbnail(); ?>
    </div>
    <?php 
                $index++;
            endif;
        endwhile;
        wp_reset_postdata();
    endif;
    ?>
    
    <button class="next" onclick="nextSlide()">Next</button>
</div>



<div class="deals">
    <h1>Our Newest Deals</h1>
    <?php
    // Query to fetch 'deals' custom post type
    $deals_query = new WP_Query(array(
        'post_type'      => 'deals',
        'posts_per_page' => 2, // Retrieve all deals
    ));

    if ($deals_query->have_posts()) :
        while ($deals_query->have_posts()) : $deals_query->the_post();
            // Fetch the price custom field
            $price = get_field('price'); // ACF method
            if (!$price) {
                $price = get_post_meta(get_the_ID(), 'price', true); // Fallback if using native WP custom fields
            }
    ?>
    <div class="deal">
        <?php if (has_post_thumbnail()) : ?>
            <div class="deal-image">
                <?php the_post_thumbnail(); ?>
            </div>
        <?php endif; ?>
        <h2 class="deal-title"><?php the_title(); ?></h2>
        <div class="deal-content">
            <?php the_excerpt(); // or the_content() for full content ?>
        </div>
        <?php if ($price) : ?>
            <div class="deal-price">
                <strong>Price:</strong> <?php echo esc_html($price); ?>
            </div>
        <?php endif; ?>
    </div>
    <?php 
        endwhile;
        wp_reset_postdata();
    endif;
    ?>
</div>


<div class="products">
    <h1>Our Featured Products</h1>
    <?php
    // Query to fetch 'products' custom post type
    $products_query = new WP_Query(array(
        'post_type'      => 'products',
        'posts_per_page' => 2, // Limit to 3 products
    ));

    if ($products_query->have_posts()) :
        while ($products_query->have_posts()) : $products_query->the_post();
            // Fetch the price custom field
            $price = get_field('price'); // ACF method
            if (!$price) {
                $price = get_post_meta(get_the_ID(), 'price', true); // Fallback if using native WP custom fields
            }
    ?>
    <div class="product">
        <?php if (has_post_thumbnail()) : ?>
            <div class="product-image">
                <?php the_post_thumbnail(); ?>
            </div>
        <?php endif; ?>
        <h2 class="product-title"><?php the_title(); ?></h2>
        <div class="product-content">
            <?php the_excerpt(); // Use the excerpt for concise product info ?>
        </div>
        <?php if ($price) : ?>
            <div class="product-price">
                <strong>Price:</strong> <?php echo esc_html($price); ?>
            </div>
        <?php endif; ?>
    </div>
    <?php 
        endwhile;
        wp_reset_postdata();
    else :
        echo '<p>No products found.</p>';
    endif;
    ?>
</div>







</div>


</body>

</html>

<?php get_footer(); ?>