<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>About Us | RXR Computers</title>
	<style>
		/* General Styles */
body {
    margin: 0;
    font-family: 'Courier New', Courier, monospace;
    background-color: #282c34;
    color: #adb5bd;
    line-height: 1.8;
}

h1, h2 {
    text-align: left;
    color: #ffffff;
    margin-left: 20px;
}

/* Header Navigation */
.nav {
    background-color: #333333;
    padding: 10px 20px;
    position: sticky;
    top: 0;
    z-index: 1000;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
}

.nav ul {
    list-style: none;
    margin: 0;
    padding: 0;
    display: flex;
    justify-content: flex-start;
    gap: 20px;
}

.nav li {
    display: inline;
}

.nav a {
    text-decoration: none;
    font-size: 1.1rem;
    font-weight: 500;
    color: #d4d4d4;
    padding: 10px 15px;
    border-radius: 4px;
    transition: background-color 0.3s ease, color 0.3s ease, transform 0.2s ease;
}

.nav a:hover {
    background-color: #4051b5;
    color: #ffffff;
    transform: scale(1.05);
}

.nav a:active {
    transform: scale(1);
}

@media (max-width: 768px) {
    .nav ul {
        flex-direction: column;
        gap: 10px;
        text-align: center;
    }
    .nav {
        text-align: center;
        justify-content: center;
    }
}

/* Header Section */
.header {
    background-color: #4051b5;
    color: #ffffff;
    padding: 30px 20px;
    margin-bottom: 20px;
    text-align: left;
    border-bottom: 3px solid #666666;
}

.header h1 {
    margin: 0;
    font-size: 2.3rem;
    text-transform: none;
    letter-spacing: 1px;
}

/* Main Content */
main {
    padding: 30px;
    max-width: 800px;
    margin: 0 auto;
    background-color: #333333;
    border-radius: 8px;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
}

section {
    margin-bottom: 40px;
}

section h2 {
    font-size: 1.8rem;
    color: #ff9800;
    margin-bottom: 20px;
    position: relative;
}

section h2::after {
    content: '';
    display: block;
    width: 50px;
    height: 3px;
    background-color: #ff9800;
    margin: 10px 0 0;
    border-radius: 1px;
}

section p, section ul {
    font-size: 1rem;
    color: #adb5bd;
    line-height: 1.6;
    margin: 15px 0;
}

section ul {
    list-style-type: circle;
    padding-left: 30px;
}

section ul li {
    margin-bottom: 15px;
}

/* Footer */
footer {
    background-color: #1e2124;
    color: #adb5bd;
    text-align: center;
    padding: 25px 0;
    font-size: 0.9rem;
    border-top: 2px solid #555555;
}

footer p {
    margin: 0;
    font-weight: 400;
    letter-spacing: 0.5px;
}


	</style>
</head>
<body>

