from abc import ABC, abstractmethod

class Printable(ABC):
    @abstractmethod
    def print_info(self):
        pass


class Book(Printable):
    def __init__(self, title, author):
        self.title = title
        self.author = author

    def print_info(self):
        print(f"Book: {self.title} by {self.author}")


book = Book("The Great Gatsby", "F. Scott Fitzgerald")
book.print_info()


class DigitalSchool:
    def __init__(self, name, city, state, courses):
        self.__name = name
        self.__city = city
        self.__state = state
        self.__courses = courses

        @property
        def name(self):
            return self.__name
        
        @name.setter
        def name(self, value):
            self.__name = value

        @property
        def city(self):
            return self.__city
        

        @city.setter
        def city(self, value):
            self.__city = value
        

        @property
        def state(self):
            return self.__state
        

        @state.setter
        def state(self, value):
            self.__state = value


        @property
        def courses(self):
            return courses.__city
        

        @courses.setter
        def courses(self, value):
            self.__courses = value

        
        def show_school_info(self):
            return {
                "name": self.__name,
                "city": self.__city,
                "state": self.__state,
                "courses": self.__courses
            }
        
        def organize_hackathon(self):
            print("Organizing a generic hackathon.")


class DS_Prishtina(DigitalSchool):
    def __init__(self, name, city, state, courses, student_number):
        super().__init__(name, city, state, courses)
        self.__student_number = student_number


        @property
        def student_number(self):
            return self.__student_number
        
        @student_number.setter
        def student_number(self, value):
            self.__student_number = value

        def Internship(self):
            print("Internship in Starlabs")

        def organize_hackathon(self):
            print("Scratch Hackathon")


    class DS_Ferizaj(DigitalSchool):
        def __init__(self, name, city, state, courses, student_number):
            super().__init__(name, city, state, courses)
            self.__student_number = student_number


        @property
        def student_number(self):
            return self.__student_number
        
        @student_number.setter
        def student_number(self, value):
            self.__student_number = value

        def SCF(self):
            print("First edition")

        def organize_hackathon(self):
            print("Data Analysis Hackathon")