class Animal:
    def eat(self):
        print("It Eats.")
    def sleep(self):
        print("It sleeps.")

class Bird(Animal):
    def fly(self):
        print("It flies in the sky")

    def sting(self):
        print("It Stings.")


class Animal:
    def sound(self):
        print("Some Generic Animal Sound")

class Dog(Animal):
    def sound(self):
        print("Woof! Woof!")


class Cat(Animal):
    def sound(self):
        print("Meow! Meow!")

animal = Animal()

animal.sound()

dog = Dog()
dog.sound()
cat = Cat()
cat.sound()


class Animal:
    def eat(self):
        print("It eats.")
    def sleep(self):
        print("It sleeps.")


class Bird(Animal):
    def fly(self):
        print("It flies in the sky.")
    def sting(self):
        print("It stings.")



class Animal:
    def sound(self):
        print("Some generic animal sound.")


class Dog(Animal):
    def sound(self):
        print("Woof! Woof!")


class Cat(Animal):
    def sound(self):
        print("Meow! Meow!")


animal = Animal()

animal.sound()


dog = Dog()

dog.sound()


cat = Cat()

cat.sound()





class Animal:
    def __init__(self, name):
        self.name = name

    def sound(self):
        print("Some generic animal sound.")

    def description(self):
        print(f"This is an animal named {self.name}.")

    
class Dog(Animal):
    def __init__(self, name, breed):
        super().__init__(name)
        self.breed = breed

    def sound(self):
        print("Woof! Woof!")

    def description(self):
        super().description()
        print(f"Breed: {self.breed}") 


class Cat(Animal):
    def __init__(self, name, color):
        super().__init__(name)
        self.color = color

    def sound(self):
        print("Meow! Meow!")

    def description(self):
        super().description()
        print(f"Color: {self.color}")


animal = Animal("Generic Animal")

animal.sound()
animal.description()

dog = Dog("Rex", "Chiwawa")
dog.sound()
dog.description()

cat = Cat("Whiskers", "Black")

cat.sound()
cat.description()

"""
class Superclass1:
class Superclass2:
class Subclass(Superclass1, Superclass2)
"""

"""
Class Superclass:

class Subclass1(Superclass):
class Subclass2(Subclass1):
"""



class Vertebrate:
    def __init__(self, backbone=True):
        self.has_backbone = backbone

    def vertebrate_info(self):
        print("Vertebrates have a backbone.")


class Aquatic:
    def __init__(self, habitat="water"):
        self.habitat = habitat

    def aquatic_info(self):
        print("Aquatic animals live in water.")



class Fish(Vertebrate, Aquatic):
    def __init__(self, species, backbone=True, habitat="water"):
        super().__init__(backbone=backbone)
        self.species = species
        self.habitat = habitat

    def fish_info(self):
            print(f"The {self.species} is a type of fish found in {self.habitat}.")

    def swim(self):
            print("The fish is swimming.")


goldfish = Fish("Goldfish")
print(goldfish.has_backbone)
print(goldfish.habitat)
goldfish.vertebrate_info()
goldfish.aquatic_info()
goldfish.fish_info()
goldfish.swim()



class Vehicle:
    def __init__(self, make, model, year):
        self.make = make
        self.model = model
        self.year = year

    def display_info(self):
        print(f"Make: {self.make}, Model: {self.model}, Year: {self.year}")


class Car(Vehicle):
    def __init__(self, make, model, year, body_style):
        super().__init__(make, model, year)
        self.body_style = body_style


class ElectricCar(Car):
    def __init__(self, make, model, year, body_style, battery_capacity):
        super().__init__(make, model, year, body_style)
        self.battery_capacity = battery_capacity

    
    def charge(self):
        print("Charging the electric car.")

tesla = ElectricCar("Tesla", "Cybertruck", 2023, 'triangular', 122.4)
tesla.display_info()
print("Body Style:", tesla.body_style)
print("Battery Capacity:", tesla.battery_capacity)
tesla.charge()


string_length = len("Hello World!")
list_length = len([1, 2, 3, 4, 5])
tuple_length = len((10, 20, 30))

print(string_length)
print(list_length)
print(tuple_length)


sum_of_list = sum([1, 2, 3, 4, 5,])
sum_of_tuple = sum((10, 5, 20))

print(sum_of_list)
print(sum_of_tuple)



max_value = max(5, 10, 3)
max_float = max(3.14, 2.71, 5.0)

print(max_value)
print(max_float)



def add(x, y):
    return x + y



def concatenate(x, y):
    return str(x) + str(y)


def operate(operation, x, y):
    return operation(x, y)



result_sum = operate(add, 3, 5)
result_concateanate = operate(concatenate, "Hello", "World")


print("Result of sum:", result_sum)
print("Result of concatenation:", result_concateanate)


class Dog:
    def __init__(self, name):
        self.name = name
    

    def sound(self):
        print(f"{self.name} makes the sound: woof!")



import math

class Shape:
    def area(self):
        pass

class Circle(Shape):
    def __init__(self, radius):
        self.radius = radius

    def area(self):
        return math.pi * self.radius ** 2
    def perm(self):
        return math.pi * self.radius *2
    

circle = Circle(5)

print(circle.area())
print(circle.perm())

